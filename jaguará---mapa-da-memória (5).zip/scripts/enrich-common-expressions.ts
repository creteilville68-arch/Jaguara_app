import fs from 'fs';
import path from 'path';
import { GoogleGenAI, Type, Schema } from '@google/genai';
import { COMMON_EXPRESSIONS } from '../src/data/commonExpressionsDictionary';

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error("GEMINI_API_KEY environment variable is required.");
  process.exit(1);
}
const ai = new GoogleGenAI({ apiKey });

async function enrichExpressions() {
  const expressionsFile = path.join(process.cwd(), 'src', 'data', 'commonExpressionsDictionary.ts');
  const fileContent = fs.readFileSync(expressionsFile, 'utf8');

  const expressions = Object.entries(COMMON_EXPRESSIONS);
  console.log(`Found ${expressions.length} expressions to enrich.`);

  let newExpressions = { ...COMMON_EXPRESSIONS };

  const batchSize = 10;
  for (let i = 0; i < expressions.length; i += batchSize) {
    const batch = expressions.slice(i, i + batchSize).filter(([key, entry]) => !entry.examples || entry.examples.length < 4);
    if (batch.length === 0) continue;

    console.log(`Processing batch ${i / batchSize + 1}: ${batch.map(b => b[0]).join(', ')}`);

    const prompt = `Você é o motor pedagógico oficial do aplicativo "Jaguará - Mapa da Memória". 
Sua tarefa é gerar exemplos de uso para as seguintes expressões francesas comuns: ${JSON.stringify(batch.map(b => b[0]))}

REGRAS CRÍTICAS E OBRIGATÓRIAS:
1. 4 EXEMPLOS PROGRESSIVOS EXATOS: Cada expressão DEVE conter obrigatoriamente exatamente 4 exemplos de uso no Quadro Comum Europeu de Referência (CECR), estruturados na seguinte progressão rigorosa:
   - Nível A1 (Iniciante)
   - Nível A2 (Básico)
   - Nível B1/B2 (Intermediário)
   - Nível C1/C2 (Avançado)
   - Cada exemplo deve vir acompanhado da respectiva tradução exata em português.

Responda ESTRITAMENTE com um array JSON com objetos contendo 'term' (a palavra exata solicitada) e 'examples':
[
  {
    "term": "expressão",
    "examples": [
      { "level": "A1", "fr": "exemplo A1", "pt": "tradução" },
      { "level": "A2", "fr": "exemplo A2", "pt": "tradução" },
      { "level": "B1-B2", "fr": "exemplo B1", "pt": "tradução" },
      { "level": "C1-C2", "fr": "exemplo C1", "pt": "tradução" }
    ]
  }
]`;

    const arrSchema: Schema = {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          term: { type: Type.STRING },
          examples: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                level: { type: Type.STRING },
                fr: { type: Type.STRING },
                pt: { type: Type.STRING }
              }
            }
          }
        }
      }
    };

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash-lite',
        contents: prompt,
        config: { responseMimeType: 'application/json', responseSchema: arrSchema }
      });
      const data = JSON.parse(response.text || '[]');
      
      for (const item of data) {
        if (item.term && newExpressions[item.term] && item.examples) {
          newExpressions[item.term].examples = item.examples;
        }
      }

      // Generate the new file content string
      const newFileContent = `import { DictionaryEntry } from '../utils/textParser';\n\nexport const COMMON_EXPRESSIONS: Record<string, Omit<DictionaryEntry, 'term'>> = ${JSON.stringify(newExpressions, null, 2)};\n`;
      fs.writeFileSync(expressionsFile, newFileContent, 'utf8');
      console.log(`Saved batch ${i / batchSize + 1}`);

    } catch (e: any) {
      console.error(`Error processing batch: ${e.message}`);
      if (e.status === 429 || e.status === 503 || e.message?.includes('429') || e.message?.includes('503') || e.message?.includes('Quota') || e.message?.includes('UNAVAILABLE')) {
        console.log("Rate limit or unavailable, waiting 40 seconds...");
        await new Promise(r => setTimeout(r, 40000));
        i -= batchSize; // Retry this batch
        continue;
      }
    }
    
    // Add delay to avoid rate limiting
    await new Promise(r => setTimeout(r, 10000));
  }

  console.log("Finished enriching expressions!");
}

enrichExpressions();
