import fs from 'fs';
import path from 'path';
import { GoogleGenAI, Type, Schema } from '@google/genai';

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error("GEMINI_API_KEY environment variable is required.");
  process.exit(1);
}
const ai = new GoogleGenAI({ apiKey });

function extractWordsFromText(text: string): string[] {
  const wordRegex = /[\p{L}\p{N}àâäéèêëîïôöùûüçÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ-]+/gu;
  const matches = text.match(wordRegex) || [];
  return matches.map(w => w.toLowerCase());
}

async function enrichLesson(lessonFilePath: string) {
  const rawData = fs.readFileSync(lessonFilePath, 'utf8');
  let lesson;
  try {
     lesson = JSON.parse(rawData);
  } catch (e) {
     return;
  }
  
  if (!lesson.paragraphs || !lesson.vocabularyDictionary) {
     return;
  }

  const allWords = new Set<string>();
  for (const p of lesson.paragraphs) {
    if (p.fr) {
      extractWordsFromText(p.fr).forEach(w => allWords.add(w));
    }
  }

  const existingWords = new Set<string>();
  for (const entry of lesson.vocabularyDictionary) {
    if (entry.term) existingWords.add(entry.term.toLowerCase());
    if (entry.wordFr) existingWords.add(entry.wordFr.toLowerCase());
    if (entry.aliases) {
      entry.aliases.forEach((a: string) => existingWords.add(a.toLowerCase()));
    }
  }

  let missingWords = Array.from(allWords).filter(w => !existingWords.has(w));
  console.log(`${path.basename(lessonFilePath)}: ${missingWords.length} missing words.`);

  if (missingWords.length === 0) return;

  const batchSize = 15;
  for (let i = 0; i < missingWords.length; i += batchSize) {
    const batch = missingWords.slice(i, i + batchSize);
    
    const prompt = `Você é o motor pedagógico oficial do aplicativo "Jaguará - Mapa da Memória". 
Sua tarefa é gerar uma lista de entradas de dicionário para as seguintes palavras francesas: ${JSON.stringify(batch)}

REGRAS CRÍTICAS E OBRIGATÓRIAS:
1. PROIBIÇÃO ABSOLUTA DE TEXTO GENÉRICO. A palavra deve ter tradução real e precisa.
2. 4 EXEMPLOS PROGRESSIVOS EXATOS: Cada palavra DEVE conter obrigatoriamente exatamente 4 exemplos de uso no Quadro Comum Europeu de Referência (CECR), estruturados na seguinte progressão rigorosa:
   - Nível A1 (Iniciante)
   - Nível A2 (Básico)
   - Nível B1/B2 (Intermediário)
   - Nível C1/C2 (Avançado)
   - Cada exemplo deve vir acompanhado da respectiva tradução exata em português.

Responda ESTRITAMENTE com um array JSON no formato:
[
  {
    "term": "palavra",
    "wordFr": "palavra",
    "definitionPt": "tradução em português",
    "definitionFr": "explicação curta em francês",
    "difficultyLevel": "A1 (ou A2, B1, etc)",
    "examples": [
      { "level": "A1", "fr": "exemplo A1", "pt": "tradução" },
      { "level": "A2", "fr": "exemplo A2", "pt": "tradução" },
      { "level": "B1-B2", "fr": "exemplo B1", "pt": "tradução" },
      { "level": "C1-C2", "fr": "exemplo C1", "pt": "tradução" }
    ]
  }
]`;

const schema: Schema = {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          term: { type: Type.STRING },
          wordFr: { type: Type.STRING },
          definitionPt: { type: Type.STRING },
          definitionFr: { type: Type.STRING },
          difficultyLevel: { type: Type.STRING },
          examples: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                level: { type: Type.STRING },
                fr: { type: Type.STRING },
                pt: { type: Type.STRING }
              }
            }
          }
        }
      }
    };

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: { responseMimeType: 'application/json', responseSchema: schema }
      });
      const data = JSON.parse(response.text || '[]');
      if (Array.isArray(data)) {
        for (const entry of data) {
          lesson.vocabularyDictionary.push(entry);
        }
        fs.writeFileSync(lessonFilePath, JSON.stringify(lesson, null, 2), 'utf8');
      }
    } catch (e: any) {
      console.error(`Error in ${path.basename(lessonFilePath)} batch:`, e.message);
      if (e.status === 429 || e.status === 503 || e.message?.includes('429') || e.message?.includes('503') || e.message?.includes('Quota') || e.message?.includes('UNAVAILABLE')) {
        console.log("Rate limit or unavailable, waiting 40 seconds...");
        await new Promise(r => setTimeout(r, 40000));
        i -= batchSize; // Retry this batch
        continue;
      }
    }
    await new Promise(r => setTimeout(r, 5000)); // Rate limit delay
  }
  console.log(`Finished ${path.basename(lessonFilePath)}`);
}

async function processAll() {
  const dataDir = path.join(process.cwd(), 'src', 'data');
  const files = fs.readdirSync(dataDir).filter(f => f.endsWith('.json') && f !== 'lessonDictionary.ts' && f !== 'commonExpressionsDictionary.ts');
  
  // We can process a few concurrently, but not too many to avoid rate limits
  const concurrency = 1;
  let running = 0;
  let currentIndex = 0;
  
  return new Promise((resolve) => {
     function next() {
       if (currentIndex >= files.length && running === 0) {
         resolve(true);
         return;
       }
       while (running < concurrency && currentIndex < files.length) {
         const file = files[currentIndex++];
         running++;
         enrichLesson(path.join(dataDir, file)).then(() => {
            running--;
            next();
         });
       }
     }
     next();
  });
}

processAll().then(() => console.log("All lessons enriched."));
