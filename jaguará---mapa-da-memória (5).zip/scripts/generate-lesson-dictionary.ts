import fs from 'fs';
import path from 'path';
import { GoogleGenAI } from '@google/genai';

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error("GEMINI_API_KEY environment variable is required.");
  process.exit(1);
}
const ai = new GoogleGenAI({ apiKey });

// Helper to normalize words (lowercase, remove punctuation)
function extractWordsFromText(text: string): string[] {
  const wordRegex = /[\p{L}\p{N}àâäéèêëîïôöùûüçÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ-]+/gu;
  const matches = text.match(wordRegex) || [];
  return matches.map(w => w.toLowerCase());
}

async function enrichLesson(lessonFilePath: string) {
  console.log(`Processing ${lessonFilePath}...`);
  const rawData = fs.readFileSync(lessonFilePath, 'utf8');
  const lesson = JSON.parse(rawData);

  // Get all unique words from all paragraphs
  const allWords = new Set<string>();
  for (const p of lesson.paragraphs) {
    if (p.fr) {
      extractWordsFromText(p.fr).forEach(w => allWords.add(w));
    }
  }

  // Get words already in dictionary
  const existingWords = new Set<string>();
  for (const entry of lesson.vocabularyDictionary) {
    if (entry.term) existingWords.add(entry.term.toLowerCase());
    if (entry.wordFr) existingWords.add(entry.wordFr.toLowerCase());
    if (entry.aliases) {
      entry.aliases.forEach((a: string) => existingWords.add(a.toLowerCase()));
    }
  }

  // Filter out existing
  let missingWords = Array.from(allWords).filter(w => !existingWords.has(w));
  console.log(`Found ${allWords.size} total words. ${missingWords.length} are missing from dictionary.`);

  if (missingWords.length === 0) {
    console.log("No missing words. Lesson is complete!");
    return;
  }

  // Batch process missing words
  const batchSize = 10;
  for (let i = 0; i < missingWords.length; i += batchSize) {
    const batch = missingWords.slice(i, i + batchSize);
    console.log(`Generating dictionary entries for batch ${i / batchSize + 1}: ${batch.join(', ')}`);
    
    const prompt = `Você é o motor pedagógico oficial do aplicativo "Jaguará - Mapa da Memória". 
Sua tarefa é gerar uma lista de entradas de dicionário para as seguintes palavras francesas: ${JSON.stringify(batch)}

REGRAS CRÍTICAS E OBRIGATÓRIAS:
1. PROIBIÇÃO ABSOLUTA DE TEXTO GENÉRICO. A palavra deve ter tradução real e precisa.
2. 4 EXEMPLOS PROGRESSIVOS EXATOS: Cada palavra DEVE conter obrigatoriamente exatamente 4 exemplos de uso no Quadro Comum Europeu de Referência (CECR), estruturados na seguinte progressão rigorosa:
   - Nível A1 (Iniciante)
   - Nível A2 (Básico)
   - Nível B1/B2 (Intermediário)
   - Nível C1/C2 (Avançado)
   - Cada exemplo deve vir acompanhado da respectiva tradução exata em português.

Responda ESTRITAMENTE com um array JSON no formato:
[
  {
    "term": "palavra",
    "wordFr": "palavra",
    "definitionPt": "tradução em português",
    "definitionFr": "explicação curta em francês",
    "difficultyLevel": "A1 (ou A2, B1, etc)",
    "examples": [
      { "level": "A1", "fr": "exemplo A1", "pt": "tradução" },
      { "level": "A2", "fr": "exemplo A2", "pt": "tradução" },
      { "level": "B1-B2", "fr": "exemplo B1", "pt": "tradução" },
      { "level": "C1-C2", "fr": "exemplo C1", "pt": "tradução" }
    ]
  }
]`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: { responseMimeType: 'application/json' }
      });
      const data = JSON.parse(response.text || '[]');
      if (Array.isArray(data)) {
        for (const entry of data) {
          lesson.vocabularyDictionary.push(entry);
        }
        // Save intermediate results
        fs.writeFileSync(lessonFilePath, JSON.stringify(lesson, null, 2), 'utf8');
      }
    } catch (e) {
      console.error(`Error processing batch: ${e}`);
    }
    
    // Add slight delay to avoid rate limiting
    await new Promise(r => setTimeout(r, 2000));
  }

  console.log(`Finished enriching ${lessonFilePath}!`);
}

const targetFile = process.argv[2];
if (!targetFile) {
  console.log("Usage: npx tsx scripts/generate-lesson-dictionary.ts src/data/paris_lesson_1.json");
  process.exit(1);
}

enrichLesson(targetFile);
