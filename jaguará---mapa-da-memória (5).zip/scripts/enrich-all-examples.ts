import fs from 'fs';
import path from 'path';
import { GoogleGenAI, Type, Schema } from '@google/genai';

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error("GEMINI_API_KEY environment variable is required.");
  process.exit(1);
}
const ai = new GoogleGenAI({ apiKey });

const schema: Schema = {
  type: Type.OBJECT,
  additionalProperties: {
    type: Type.OBJECT,
    properties: {
      examples: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            level: { type: Type.STRING },
            fr: { type: Type.STRING },
            pt: { type: Type.STRING }
          }
        }
      }
    }
  }
};

async function processLessons() {
  const dataDir = path.join(process.cwd(), 'src', 'data');
  const files = fs.readdirSync(dataDir).filter(f => f.endsWith('.json') && !f.includes('dictionary'));

  for (const file of files) {
    const filePath = path.join(dataDir, file);
    const rawData = fs.readFileSync(filePath, 'utf8');
    let lesson;
    try {
      lesson = JSON.parse(rawData);
    } catch (e) {
      continue;
    }

    if (!lesson.vocabularyDictionary) continue;

    let modified = false;
    const entriesToEnrich = lesson.vocabularyDictionary.filter((entry: any) => !entry.examples || entry.examples.length < 4);
    
    if (entriesToEnrich.length > 0) {
      console.log(`[${file}] Found ${entriesToEnrich.length} entries missing examples.`);
      
      const batchSize = 5;
      for (let i = 0; i < entriesToEnrich.length; i += batchSize) {
        const batch = entriesToEnrich.slice(i, i + batchSize);
        const terms = batch.map((e: any) => e.term || e.wordFr).filter(Boolean);
        if (terms.length === 0) continue;

        console.log(`[${file}] Processing batch ${i/batchSize + 1}: ${terms.join(', ')}`);

        const prompt = `Você é o motor pedagógico oficial do aplicativo "Jaguará - Mapa da Memória". 
Sua tarefa é gerar exemplos de uso para as seguintes palavras/expressões em francês: ${JSON.stringify(terms)}

REGRAS CRÍTICAS E OBRIGATÓRIAS:
1. 4 EXEMPLOS PROGRESSIVOS EXATOS: Cada expressão DEVE conter obrigatoriamente exatamente 4 exemplos de uso no Quadro Comum Europeu de Referência (CECR), estruturados na seguinte progressão rigorosa:
   - Nível A1 (Iniciante)
   - Nível A2 (Básico)
   - Nível B1/B2 (Intermediário)
   - Nível C1/C2 (Avançado)
   - Cada exemplo deve vir acompanhado da respectiva tradução exata em português.

Responda ESTRITAMENTE com um array JSON com objetos contendo 'term' (a palavra exata solicitada) e 'examples':
[
  {
    "term": "palavra",
    "examples": [
      { "level": "A1", "fr": "exemplo A1", "pt": "tradução" },
      { "level": "A2", "fr": "exemplo A2", "pt": "tradução" },
      { "level": "B1-B2", "fr": "exemplo B1", "pt": "tradução" },
      { "level": "C1-C2", "fr": "exemplo C1", "pt": "tradução" }
    ]
  }
]`;

        const arrSchema: Schema = {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              term: { type: Type.STRING },
              examples: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    level: { type: Type.STRING },
                    fr: { type: Type.STRING },
                    pt: { type: Type.STRING }
                  }
                }
              }
            }
          }
        };

        try {
          const response = await ai.models.generateContent({
            model: 'gemini-3.6-flash',
            contents: prompt,
            config: { responseMimeType: 'application/json', responseSchema: arrSchema }
          });
          
          const data = JSON.parse(response.text || '[]');
          
          for (const entry of batch) {
            const key = entry.term || entry.wordFr;
            const match = data.find((d: any) => d.term === key);
            if (match && match.examples) {
              entry.examples = match.examples;
              modified = true;
            }
          }
        } catch (e: any) {
          console.error(`[${file}] Error processing batch: ${e.message}`);
          if (e.status === 429 || e.status === 503 || e.message?.includes('429') || e.message?.includes('503') || e.message?.includes('Quota') || e.message?.includes('UNAVAILABLE')) {
            console.log("Rate limit or unavailable, waiting 40 seconds...");
            await new Promise(r => setTimeout(r, 40000));
            i -= batchSize; // Retry
          }
        }
        await new Promise(r => setTimeout(r, 5000)); // Delay between requests
      }
      
      if (modified) {
        fs.writeFileSync(filePath, JSON.stringify(lesson, null, 2), 'utf8');
        console.log(`[${file}] Saved updates.`);
      }
    }
  }
  console.log("Finished all lessons!");
}

processLessons();
