import React, { useState } from 'react';
import { Lesson, DomainType } from '../types/map';
import { FRANCE_CITIES } from '../data/franceMapData';
import { BookOpen, Plus, Sparkles, MapPin, CheckCircle, ArrowRight, Trash2 } from 'lucide-react';
import { LessonReader } from './LessonReader';
import parisLesson1Data from '../data/paris_lesson_1.json';
import parisLesson2Data from '../data/paris_lesson_2.json';
import parisLesson3Data from '../data/paris_lesson_3.json';
import parisLesson4Data from '../data/paris_lesson_4.json';
import parisLesson5Data from '../data/paris_lesson_5.json';
import parisLesson6Data from '../data/paris_lesson_6.json';
import parisLesson7Data from '../data/paris_lesson_7.json';
import parisLesson8Data from '../data/paris_lesson_8.json';
import parisLesson9Data from '../data/paris_lesson_9.json';
import parisLesson10Data from '../data/paris_lesson_10.json';
import parisLesson11Data from '../data/paris_lesson_11.json';
import parisLesson12Data from '../data/paris_lesson_12.json';
import parisLesson13Data from '../data/paris_lesson_13.json';
import parisLesson14Data from '../data/paris_lesson_14.json';
import parisLesson15Data from '../data/paris_lesson_15.json';
import parisLesson16Data from '../data/paris_lesson_16.json';
import parisLesson17Data from '../data/paris_lesson_17.json';
import parisLesson18Data from '../data/paris_lesson_18.json';
import parisLesson19Data from '../data/paris_lesson_19.json';
import parisLesson20Data from '../data/paris_lesson_20.json';
import parisLesson21Data from '../data/paris_lesson_21.json';
import parisLesson22Data from '../data/paris_lesson_22.json';
import parisLesson23Data from '../data/paris_lesson_23.json';
import parisLesson24Data from '../data/paris_lesson_24.json';
import parisLesson25Data from '../data/paris_lesson_25.json';
import amiensLesson1Data from '../data/amiens_lesson_1.json';

const PARIS_OFFICIAL_LESSONS = [
  parisLesson1Data,
  parisLesson2Data,
  parisLesson3Data,
  parisLesson4Data,
  parisLesson5Data,
  parisLesson6Data,
  parisLesson7Data,
  parisLesson8Data,
  parisLesson9Data,
  parisLesson10Data,
  parisLesson11Data,
  parisLesson12Data,
  parisLesson13Data,
  parisLesson14Data,
  parisLesson15Data,
  parisLesson16Data,
  parisLesson17Data,
  parisLesson18Data,
  parisLesson19Data,
  parisLesson20Data,
  parisLesson21Data,
  parisLesson22Data,
  parisLesson23Data,
  parisLesson24Data,
  parisLesson25Data,
];

const AMIENS_OFFICIAL_LESSONS = [
  amiensLesson1Data,
];

const ALL_OFFICIAL_LESSONS = [
  ...PARIS_OFFICIAL_LESSONS,
  ...AMIENS_OFFICIAL_LESSONS,
];

interface LessonsViewProps {
  lessons: Lesson[];
  onAddLesson: (lesson: Lesson) => void;
  onNavigateToCity: (cityId: string) => void;
  onNavigateToFlashcards?: () => void;
  initialCityId?: string;
}

export const LessonsView: React.FC<LessonsViewProps> = ({
  lessons,
  onAddLesson,
  onNavigateToCity,
  onNavigateToFlashcards,
  initialCityId,
}) => {
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [title, setTitle] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [domain, setDomain] = useState<DomainType>('Cotidiano');
  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [activeOfficialLessonId, setActiveOfficialLessonId] = useState<string | null>(null);
  const [selectedCityTab, setSelectedCityTab] = useState<'paris' | 'amiens'>(
    initialCityId === 'amiens' ? 'amiens' : 'paris'
  );

  const handleAnalyzeAndSave = async () => {
    if (!title.trim() || !content.trim()) return;
    setAnalyzing(true);

    try {
      const res = await fetch('/api/ai/analyze-lesson', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, text: content })
      });
      const data = await res.json();

      const newLesson: Lesson = {
        id: 'lesson_' + Date.now(),
        title,
        content,
        countryId: 'FR',
        cityId: data.suggestedCityId || 'paris',
        domain: (data.domain as DomainType) || domain,
        dateAdded: new Date().toISOString(),
        wordsLearned: data.wordsLearned || ['français', 'étude'],
        status: 'mastered',
        accuracyScore: 95
      };

      onAddLesson(newLesson);
      setTitle('');
      setContent('');
      setShowAddModal(false);
    } catch (e) {
      console.error('Failed to analyze lesson', e);
    } finally {
      setAnalyzing(false);
    }
  };

  const activeOfficialLesson = ALL_OFFICIAL_LESSONS.find(
    (l: any) => l.id === activeOfficialLessonId
  );
  if (activeOfficialLesson) {
    return (
      <LessonReader
        onBack={() => setActiveOfficialLessonId(null)}
        onNavigateToFlashcards={onNavigateToFlashcards}
        lessonData={activeOfficialLesson as any}
      />
    );
  }

  return (
    <div className="flex-1 bg-slate-950 p-6 md:p-8 overflow-y-auto space-y-6 text-slate-200 select-none">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
            Caminho B: Suas Aulas → Mapa da Memória
          </span>
          <h2 className="text-2xl font-black text-white mt-0.5">Minhas Aulas & Conteúdos</h2>
          <p className="text-xs text-slate-400">
            Adicione seus próprios textos ou explore as Aulas Oficiais Interativas com dicionário e SRS!
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center space-x-2 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Nova Aula / Texto</span>
        </button>
      </div>

      {/* Trilha Oficial - Seletor de Cidades */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
          <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Trilha Francês pela França (11 Cidades) • Selecione a Cidade:</span>
          </h3>
          <span className="text-[10px] font-extrabold text-amber-300 bg-amber-950/80 px-2.5 py-1 rounded-full border border-amber-800/60 uppercase">
            {selectedCityTab === 'paris' ? 'Cidade #1: Paris • Nível A1 (Iniciante)' : 'Cidade #2: Amiens • Nível A1/A2 (Transição)'}
          </span>
        </div>

        {/* Tab Bar Cidades com Regra de Evolução Pedagógica A1 -> C2 */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-800">
          <button
            onClick={() => setSelectedCityTab('paris')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 shrink-0 transition-all ${
              selectedCityTab === 'paris'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950/50 border border-emerald-500'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>#1 Paris • Nível A1 (25 Aulas)</span>
          </button>

          <button
            onClick={() => setSelectedCityTab('amiens')}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 shrink-0 transition-all ${
              selectedCityTab === 'amiens'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-950/50 border border-amber-400 font-extrabold'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>#2 Amiens • Nível A1/A2 (Aula 1)</span>
          </button>

          <div className="px-3 py-2 bg-slate-900/60 border border-slate-800/80 rounded-xl text-[11px] font-medium text-slate-400 shrink-0">
            #3 Lille • A2
          </div>
          <div className="px-3 py-2 bg-slate-900/60 border border-slate-800/80 rounded-xl text-[11px] font-medium text-slate-400 shrink-0">
            #4 Mont St-Michel • A2/B1
          </div>
          <div className="px-3 py-2 bg-slate-900/60 border border-slate-800/80 rounded-xl text-[11px] font-medium text-slate-400 shrink-0">
            #5 Tours • B1
          </div>
          <div className="px-3 py-2 bg-slate-900/60 border border-slate-800/80 rounded-xl text-[11px] font-medium text-slate-400 shrink-0">
            #6 Bordeaux • B1+
          </div>
          <div className="px-3 py-2 bg-slate-900/60 border border-slate-800/80 rounded-xl text-[11px] font-medium text-slate-400 shrink-0">
            #7 Toulouse • B2
          </div>
          <div className="px-3 py-2 bg-slate-900/60 border border-slate-800/80 rounded-xl text-[11px] font-medium text-slate-400 shrink-0">
            #8 Lyon • B2+
          </div>
          <div className="px-3 py-2 bg-slate-900/60 border border-slate-800/80 rounded-xl text-[11px] font-medium text-slate-400 shrink-0">
            #9 Marselha • C1
          </div>
          <div className="px-3 py-2 bg-slate-900/60 border border-slate-800/80 rounded-xl text-[11px] font-medium text-slate-400 shrink-0">
            #10 Estrasburgo • C1+
          </div>
          <div className="px-3 py-2 bg-slate-900/60 border border-slate-800/80 rounded-xl text-[11px] font-medium text-slate-400 shrink-0">
            #11 Nice • C2 (Maestria)
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 mt-2">
          {(selectedCityTab === 'paris' ? PARIS_OFFICIAL_LESSONS : AMIENS_OFFICIAL_LESSONS).map((lesson: any, index: number) => {
            const isFirst = index === 0;
            const isSecond = index === 1;
            const cityTitle = selectedCityTab === 'paris' ? 'Paris #1' : 'Amiens #2';
            const cityBadge = selectedCityTab === 'paris' ? 'Cidade #1 Paris' : 'Cidade #2 Amiens';

            return (
              <div
                key={lesson.id}
                className={`bg-gradient-to-r ${
                  isFirst
                    ? 'from-emerald-500/15 via-slate-900 to-slate-900 border-2 border-emerald-500/50'
                    : isSecond
                    ? 'from-amber-500/10 via-slate-900 to-slate-900 border border-slate-800 hover:border-slate-700'
                    : 'from-emerald-500/10 via-slate-900 to-slate-900 border border-slate-800 hover:border-slate-700'
                } rounded-3xl p-6 shadow-xl relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-all`}
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                    <span className="text-[10px] font-extrabold text-amber-400 bg-amber-950 px-2.5 py-0.5 rounded-full border border-amber-800 uppercase tracking-wide">
                      {lesson.domain} • {cityBadge} • Lição {index + 1}
                    </span>
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-2.5 py-0.5 rounded-full border border-emerald-800">
                      {lesson.level}
                    </span>
                  </div>
                  <h3 className="text-lg font-black text-white">
                    {lesson.titleFr || lesson.title}
                  </h3>
                  <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
                    {lesson.subtitlePt || lesson.summaryPt || lesson.subtitleFr || ''}
                  </p>
                </div>

                <button
                  onClick={() => setActiveOfficialLessonId(lesson.id)}
                  className={`px-5 py-3 ${
                    isFirst
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                      : isSecond
                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  } font-extrabold text-xs rounded-xl shadow-lg transition-all flex items-center space-x-2 shrink-0`}
                >
                  <BookOpen className="w-4 h-4 text-emerald-400" />
                  <span>Ler Lição {index + 1} ({cityTitle})</span>
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Lesson Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Analisar e Vincular Nova Aula ao Mapa</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-400 font-semibold">Título da Aula:</label>
                <input
                  type="text"
                  placeholder="Ex: La Révolution Française et Paris..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full mt-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 font-semibold">Conteúdo / Texto em Francês:</label>
                <textarea
                  rows={5}
                  placeholder="Cole ou escreva o texto estudado..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full mt-1 bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-400 font-semibold">Domínio de Uso:</label>
                <select
                  value={domain}
                  onChange={(e) => setDomain(e.target.value as DomainType)}
                  className="w-full mt-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white outline-none"
                >
                  <option value="Cotidiano">Cotidiano</option>
                  <option value="Cultura">Cultura & História</option>
                  <option value="Acadêmico">Acadêmico</option>
                  <option value="Profissional">Profissional</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 text-xs text-slate-400 hover:text-white"
              >
                Cancelar
              </button>
              <button
                onClick={handleAnalyzeAndSave}
                disabled={analyzing}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center space-x-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>{analyzing ? 'Analisando com IA...' : 'Analisar e Salvar'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* List of Lessons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {lessons.map((lesson) => {
          const linkedCity = FRANCE_CITIES.find((c) => c.id === lesson.cityId);

          return (
            <div
              key={lesson.id}
              className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 hover:border-slate-700 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-800/60 uppercase">
                    {lesson.domain}
                  </span>
                  <h3 className="text-sm font-bold text-white mt-1.5">{lesson.title}</h3>
                </div>

                {linkedCity && (
                  <button
                    onClick={() => onNavigateToCity(linkedCity.id)}
                    className="flex items-center space-x-1 text-xs text-emerald-400 hover:underline font-medium bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800"
                  >
                    <MapPin className="w-3 h-3" />
                    <span>{linkedCity.name}</span>
                  </button>
                )}
              </div>

              <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed italic">
                "{lesson.content}"
              </p>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <div className="flex flex-wrap gap-1">
                  {lesson.wordsLearned.slice(0, 4).map((w) => (
                    <span
                      key={w}
                      className="text-[10px] bg-slate-950 text-slate-300 px-2 py-0.5 rounded border border-slate-800"
                    >
                      {w}
                    </span>
                  ))}
                </div>

                <span className="text-[10px] text-emerald-400 font-semibold">
                  Dominado (95%)
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
