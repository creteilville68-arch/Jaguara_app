import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy initialization of Gemini API Client
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY process env is missing');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
}

// 1. LOCATION EXPERIENCE ENDPOINT
app.post('/api/ai/location-experience', async (req, res) => {
  try {
    const { countryName, cityName, locationName, category, tags, userLevel = 'B1' } = req.body;
    
    let ai;
    try {
      ai = getGeminiClient();
    } catch {
      // Fallback response if GEMINI_API_KEY is not configured yet
      return res.json({
        locationName,
        cityName,
        culturalInsightPt: `O local ${locationName} em ${cityName} é um dos pontos mais emblemáticos da cultura francesa, refletindo séculos de história, arquitetura e vida cotidiana.`,
        culturalInsightFr: `${locationName} à ${cityName} est un lieu emblématique de la culture française, reflétant des siècles d'histoire et de vie quotidienne.`,
        bilingualSentences: [
          {
            pt: `Este local histórico fica no coração de ${cityName}.`,
            fr: `Ce site historique se trouve au cœur de ${cityName}.`,
            note: 'Vocabulário: au cœur de = no coração de'
          },
          {
            pt: 'Os visitantes apreciam a atmosfera única e a cultura local.',
            fr: 'Les visiteurs apprécient l\'atmosphère unique et la culture locale.',
            note: 'Gramática: verbo apprécier no presente (présent de l\'indicatif)'
          }
        ],
        vocabulary: [
          { wordFr: 'un monument', wordPt: 'um monumento', phonetic: 'œ̃ mɔnymɑ̃', exampleFr: 'C\'est un monument très célèbre.', examplePt: 'É um monumento muito famoso.' },
          { wordFr: 'la culture', wordPt: 'a cultura', phonetic: 'la kyltyʁ', exampleFr: 'J\'adore la culture française.', examplePt: 'Adoro a cultura francesa.' },
          { wordFr: 'visiter', wordPt: 'visitar', phonetic: 'vizite', exampleFr: 'Nous allons visiter ce lieu.', examplePt: 'Nós vamos visitar este local.' }
        ],
        grammarTip: {
          ruleTitle: 'Uso de Artigos e Preposições de Lugar',
          explanationPt: 'Em francês, usamos a preposição "à" para cidades e "en" ou "au" para países e regiões.',
          exampleFr: 'Je suis à Paris, en France.',
          examplePt: 'Eu estou em Paris, na França.',
          practiceQuestion: 'Como se diz "Eu moro em Lyon"?',
          options: ['J\'habite à Lyon', 'J\'habite en Lyon', 'J\'habite au Lyon'],
          correctIndex: 0
        },
        shadowingPhrases: [
          { id: '1', fr: `Bienvenue à ${locationName}!`, pt: `Bem-vindo a ${locationName}!` },
          { id: '2', fr: `C'est un endroit magnifique à visiter.`, pt: `É um lugar magnífico para visitar.` }
        ],
        mentorPromptContext: `O usuário está explorando ${locationName} em ${cityName}.`
      });
    }

    const prompt = `Você é o tutor pedagógico do aplicativo JAGUARÁ.
Gere uma experiência de aprendizagem de francês imersiva e contextualizada para o local:
- País: ${countryName || 'França'}
- Cidade: ${cityName}
- Local: ${locationName}
- Categoria: ${category}
- Tags: ${JSON.stringify(tags || [])}
- Nível do Aluno: ${userLevel}

Responda ESTRITAMENTE em formato JSON com o seguinte schema:
- culturalInsightPt: explicação cultural/histórica curta em português.
- culturalInsightFr: a mesma explicação em francês adequado ao nível do aluno.
- bilingualSentences: array de 2 objetos { pt, fr, note }.
- vocabulary: array de 4 palavras { wordFr, wordPt, phonetic, exampleFr, examplePt }.
- grammarTip: objeto { ruleTitle, explanationPt, exampleFr, examplePt, practiceQuestion, options (array de 3 frases), correctIndex (number 0-2) }.
- shadowingPhrases: array de 3 frases { id, fr, pt }.
- mentorPromptContext: frase curta contextual para o Mentor Irlan.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ locationName, cityName, ...parsed });
  } catch (error: any) {
    console.error('Location experience AI error:', error);
    res.status(500).json({ error: error.message || 'Error generating location experience' });
  }
});

// 2. MENTOR IRLAN CONTEXTUAL CHAT
app.post('/api/ai/mentor-chat', async (req, res) => {
  try {
    const { userMessage, cityName, locationName, topic, userLevel = 'B1', chatHistory = [] } = req.body;
    
    let ai;
    try {
      ai = getGeminiClient();
    } catch {
      return res.json({
        responseFr: `Bonjour! C'est fascinant d'être ici à ${locationName || cityName || 'Paris'}. Comment puis-je vous aider aujourd'hui?`,
        responsePt: `Olá! É fascinante estar aqui em ${locationName || cityName || 'Paris'}. Como posso te ajudar hoje?`,
        correction: null,
        suggestedNextTopic: 'Perguntar sobre a história do local ou pedir recomendações em francês.'
      });
    }

    const systemInstruction = `Você é o Mentor Irlan no aplicativo JAGUARÁ, um mentor de idiomas caloroso, culto e motivador.
O aluno está virtualmente explorando o Mapa da Memória na França.
Contexto atual:
- Cidade: ${cityName || 'Paris'}
- Local: ${locationName || 'Centro'}
- Tema: ${topic || 'Cultura & Viagem'}
- Nível do aluno: ${userLevel}

Regras da conversa:
1. Responda em Francês com tradução natural em Português.
2. Se o aluno cometer algum erro gramatical em Francês, inclua uma correção gentil e construtiva.
3. Mantenha a fala conectada ao local onde ele está viajando no mapa.
4. Estimule a conversação contínua.

Responda ESTRITAMENTE em formato JSON com:
- responseFr: texto da resposta em francês.
- responsePt: texto traduzido em português.
- correction: objeto opcional { original, corrected, explanation } se houver erro do aluno, senão null.
- suggestedNextTopic: sugestão curta de próxima pergunta/tópico.`;

    const contents = [
      ...chatHistory.map((h: any) => `${h.sender === 'user' ? 'Aluno' : 'Mentor'}: ${h.text}`),
      `Aluno: ${userMessage}`
    ].join('\n');

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents,
      config: {
        systemInstruction,
        responseMimeType: 'application/json'
      }
    });

    const data = JSON.parse(response.text || '{}');
    return res.json(data);
  } catch (error: any) {
    console.error('Mentor chat AI error:', error);
    res.status(500).json({ error: error.message || 'Error processing mentor conversation' });
  }
});

// 3. RECOMMENDED JOURNEY AI CREATOR
app.post('/api/ai/recommended-journey', async (req, res) => {
  try {
    const { userMetrics } = req.body;
    let ai;
    try {
      ai = getGeminiClient();
    } catch {
      return res.json({
        id: 'journey_' + Date.now(),
        title: 'Trilha Personalizada: Encantos da França',
        description: 'Uma rota equilibrada combinando história em Paris, realeza em Versailles, espumantes em Reims e gastronomia em Lyon.',
        citySequence: ['paris', 'versailles', 'reims', 'lyon', 'marseille', 'nice'],
        reasoning: 'Essa trilha reforça gramática de passado e vocabulário cotidiano com base em suas lições recentes.'
      });
    }

    const prompt = `Como arquiteto pedagógico do JAGUARÁ, crie uma Trilha de Aprendizagem Recomendada pelo Mapa da França para um aluno com o seguinte perfil:
${JSON.stringify(userMetrics || {})}

Selecione entre 4 e 6 cidades da lista: ['paris', 'versailles', 'reims', 'strasbourg', 'lyon', 'marseille', 'nice', 'bordeaux', 'toulouse', 'lille', 'nantes', 'rouen', 'tours', 'rennes', 'montpellier', 'grenoble'].

Retorne um JSON com:
- title: título atraente para a jornada.
- description: breve resumo motivador.
- citySequence: array de IDs de cidades na ordem recomendada.
- reasoning: explicação pedagógica de por que esta rota foi recomendada.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const data = JSON.parse(response.text || '{}');
    return res.json(data);
  } catch (error: any) {
    console.error('Journey AI error:', error);
    res.status(500).json({ error: error.message || 'Error generating journey' });
  }
});

// 4. CAMINHO B: ANALYZE CUSTOM USER LESSON & MAP ATTACHMENT
app.post('/api/ai/analyze-lesson', async (req, res) => {
  try {
    const { text, title } = req.body;
    let ai;
    try {
      ai = getGeminiClient();
    } catch {
      return res.json({
        suggestedCityId: 'paris',
        suggestedLocationId: 'le_marais',
        domain: 'Cotidiano',
        wordsLearned: ['bonjour', 'voyage', 'français', 'culture'],
        summaryPt: 'Análise automática da lição conectando o texto a Paris no Mapa da Memória.'
      });
    }

    const prompt = `Analise este texto trazido pelo aluno para o JAGUARÁ:
Título: "${title}"
Conteúdo: "${text}"

Identifique:
1. Qual cidade da França mais se relaciona com o tema (Opções: paris, versailles, reims, strasbourg, lyon, marseille, nice, bordeaux, toulouse, lille, nantes, rouen, tours, rennes, montpellier, grenoble).
2. Qual domínio de uso (Cotidiano, Acadêmico, Profissional, Cultura).
3. Uma lista de 4 a 6 palavras-chave mais importantes em francês aprendidas no texto.
4. Um pequeno resumo pedagógico em português.

Responda em JSON:
{
  "suggestedCityId": "string",
  "domain": "string",
  "wordsLearned": ["array de strings"],
  "summaryPt": "string"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });

    const data = JSON.parse(response.text || '{}');
    return res.json(data);
  } catch (error: any) {
    console.error('Analyze lesson error:', error);
    res.status(500).json({ error: error.message || 'Error analyzing lesson' });
  }
});

// 5. CURIOSITY OF THE DAY ENDPOINT
app.post('/api/ai/daily-curiosity', async (req, res) => {
  try {
    const { cityName = 'Paris' } = req.body;
    let ai;
    try {
      ai = getGeminiClient();
    } catch {
      return res.json({
        id: 'curiosity_' + Date.now(),
        cityName: 'Paris',
        locationName: 'Tour Eiffel',
        title: 'A Cor Original da Torre Eiffel',
        factPt: 'Quando foi construída em 1889, a Torre Eiffel era pintada de vermelho-marrom! Ao longo de mais de 130 anos, ela já foi pintada de amarelo, marrom-ocre e atualmente tem a cor exclusiva "Brons de la Tour Eiffel".',
        relatedWords: [
          { fr: 'la peinture', pt: 'a pintura' },
          { fr: 'construire', pt: 'construir' },
          { fr: 'la couleur', pt: 'a cor' }
        ],
        miniQuiz: {
          question: 'De que cor era originalmente a Torre Eiffel em 1889?',
          options: ['Vermelho-marrom', 'Azul celeste', 'Dourado brilhante'],
          correctIndex: 0,
          explanation: 'Ela foi pintada de vermelho-marrom (rouge-brun) para proteger o ferro contra a oxidação.'
        }
      });
    }

    const prompt = `Gere uma Curiosidade do Dia cativante sobre a cultura/história da cidade de ${cityName} na França para alunos do JAGUARÁ.
Retorne um JSON com:
- cityName
- locationName
- title: título curto instigante.
- factPt: parágrafo curto sobre o fato curioso em português.
- relatedWords: array de 3 objetos { fr, pt }.
- miniQuiz: objeto { question, options (array de 3), correctIndex (0-2), explanation }.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: { responseMimeType: 'application/json' }
    });

    const data = JSON.parse(response.text || '{}');
    return res.json(data);
  } catch (error: any) {
    console.error('Curiosity error:', error);
    res.status(500).json({ error: error.message || 'Error generating curiosity' });
  }
});

// 6. DYNAMIC DICTIONARY ENTRY GENERATOR
app.post('/api/ai/generate-dictionary-entry', async (req, res) => {
  try {
    const { word, contextFr } = req.body;
    let ai;
    try {
      ai = getGeminiClient();
    } catch {
      return res.json({
        term: word,
        wordFr: word,
        definitionPt: 'tradução gerada offline',
        definitionFr: 'Mot de vocabulaire',
        difficultyLevel: 'A2',
        examples: [
          { level: 'A1', fr: `C'est un(e) ${word}.`, pt: `Isso é um(a) ${word}.` },
          { level: 'A2', fr: `Le mot ${word} est utile.`, pt: `A palavra ${word} é útil.` },
          { level: 'B1-B2', fr: `Dans ce contexte, ${word} a un sens précis.`, pt: `Neste contexto, ${word} tem um significado preciso.` },
          { level: 'C1-C2', fr: `L'usage du terme ${word} s'avère pertinent.`, pt: `O uso do termo ${word} se mostra pertinente.` }
        ]
      });
    }

    const prompt = `Você é o motor pedagógico oficial do aplicativo "Jaguará - Mapa da Memória". 
Sua tarefa é gerar uma entrada de dicionário para a palavra francesa "${word}".
Contexto original da aula onde a palavra apareceu (opcional): "${contextFr || ''}"

REGRAS CRÍTICAS E OBRIGATÓRIAS (VIOLAÇÃO PROIBIDA):
1. PROIBIÇÃO ABSOLUTA DE TEXTO GENÉRICO. A palavra deve ter tradução real, precisa e contextualizada (se houver contexto).
2. 4 EXEMPLOS PROGRESSIVOS EXATOS: A palavra DEVE conter obrigatoriamente exatamente 4 exemplos de uso no Quadro Comum Europeu de Referência (CECR), estruturados na seguinte progressão rigorosa:
   - Nível A1 (Iniciante)
   - Nível A2 (Básico)
   - Nível B1/B2 (Intermediário)
   - Nível C1/C2 (Avançado)
   - Cada exemplo deve vir acompanhado da respectiva tradução exata em português.

Responda ESTRITAMENTE em formato JSON:
{
  "term": "${word}",
  "wordFr": "${word}",
  "definitionPt": "tradução em português",
  "definitionFr": "explicação curta em francês",
  "difficultyLevel": "Nível estimado",
  "examples": [
    { "level": "A1", "fr": "exemplo", "pt": "tradução" },
    { "level": "A2", "fr": "exemplo", "pt": "tradução" },
    { "level": "B1-B2", "fr": "exemplo", "pt": "tradução" },
    { "level": "C1-C2", "fr": "exemplo", "pt": "tradução" }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: { responseMimeType: 'application/json' }
    });

    const data = JSON.parse(response.text || '{}');
    return res.json(data);
  } catch (error: any) {
    console.error('Dictionary error:', error);
    res.status(500).json({ error: error.message || 'Error generating dictionary entry' });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
